<?php
//TERMINOS Y CONDICIONES DEL SERVICIO
require 'cfg.inc.php';
$dndtoy = 21;
$buscador = false;
include 'header.php';
?>
<body class="stretched">
	<div id="wrapper" class="clearfix">
		<?php /* MENÚ */?>
		<header id="header" class="full-header dark">
		<?php include 'menu.php';?>
		</header>
		<?php /* CONTENIDO */ ?>
		<section id="content">
			<div class="content-wrap bg-light">
				<div class="container clearfix mb-5">
					<h3>Términos y Condiciones del Servicio</h3>
					<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem doloribus unde eum, illum, accusamus necessitatibus optio animi voluptatibus, odio veritatis in! Ab nesciunt recusandae ipsum! Culpa, unde. At, vel error?. Dolor sit amet consectetur adipisicing elit. Corporis quisquam iure quas consequatur? Quasi corporis veritatis aliquam ex adipisci laborum iure? Numquam suscipit perspiciatis sint. Vitae quisquam provident deserunt autem.</p>
					<p>Sit amet, consectetur adipisicing elit. Esse quas amet voluptatum ea omnis voluptate nesciunt consectetur magnam praesentium dicta! Nam deleniti amet ipsa quis incidunt eius error corporis alias. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Iste accusantium fugiat doloremque cumque hic et minima, assumenda ipsa eum, suscipit nesciunt aliquid quas temporibus enim ipsum commodi, dignissimos incidunt reiciendis.</p>
				</div>
            </div>
		</section>
		<?php include 'footer.php';?>
	</div>
	<div id="gotoTop" class="icon-line-chevron-up"></div>
	<?php require 'scripts.php';?>
</body>
</html>