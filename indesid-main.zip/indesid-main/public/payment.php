<?php
//Detalles del pago
if (isset($_SESSION['cod'])) {
?>

<?php
} else {
  header("location:ingreso.php");
}
