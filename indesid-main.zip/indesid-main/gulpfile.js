'use strict';
const gulp = require('gulp');
const concat = require('gulp-concat');
const rename = require('gulp-rename');
//Archivos CSS
const cleanCSS = require('gulp-clean-css');
//Archivos JS
const uglify = require('gulp-uglify');
const obfuscator = require('gulp-javascript-obfuscator');
//Rutas
const paths = {
	sourceCSS: './src/css/*.css',
	sourceJS: './src/js/single/*.js',
	destCSS: './dist/css',
	destJS: './dist/js',
};

//Javascript solos
gulp.task('solosJS', () => {
	return gulp
		.src(paths.sourceJS)
		.pipe(uglify())
		.pipe(rename({ suffix: '.min' }))
		.pipe(gulp.dest(paths.destJS));
});

//Javascript grupo
gulp.task('bundleJS', () => {
	return gulp
		.src([
			'src/js/plugins.js',
			'src/js/functions.js',
			'src/js/sweetalert.js',
			'src/js/select.js',
			'src/js/datepicker.js',
			'src/js/datatable.js',
			'src/js/fileinput.js',
			'src/js/phoneinput.js',
			'src/js/pdfobject.js',
			'src/js/numeric.js',
		])
		.pipe(uglify())
		.pipe(concat('bundle.min.js'))
		.pipe(gulp.dest(paths.destJS));
});

//Hojas de estilo
gulp.task('bundleCSS', () => {
	return gulp
		.src([
			'src/css/bootstrap.css',
			'src/css/indesid.css',
			'src/css/animate.css',
			'src/css/dark.css',
			'src/css/icons.css',
			'src/css/datatable.css',
			'src/css/datepicker.css',
			'src/css/select.css',
			'src/css/telefono.css',
			'src/css/custom.css',
		])
		.pipe(cleanCSS())
		.pipe(concat('bundle.min.css'))
		.pipe(gulp.dest(paths.destCSS));
});

gulp.task('all', gulp.parallel(['bundleCSS', 'bundleJS']));
gulp.task('default', gulp.series(['solosJS', 'bundleJS', 'bundleCSS']));
